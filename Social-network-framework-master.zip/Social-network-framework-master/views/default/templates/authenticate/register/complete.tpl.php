<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
				<h1>Welcome to DINO SPACE!</h1>
				<p>Thank you for joining DINO SPACE!</p>
				
				
				</div>
			
			</div>