
<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
				<h1>{heading}</h1>
				<p>{content}</p>
				</div>
			
			</div>