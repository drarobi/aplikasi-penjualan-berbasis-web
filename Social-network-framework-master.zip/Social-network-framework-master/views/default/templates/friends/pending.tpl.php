			<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
					<h1>Pending connections</h1>
					<!-- START pending -->
					<p><strong>{usera_name}</strong> wants to be <strong>{type_plural_name}</strong> with you.</p>
					<p><a href="relationship/approve/{ID}">Approve</a> or <a href="relationship/reject/{ID}">Reject</a> this request.</p>
					<hr />
					<!-- END pending -->
					
				</div>
			
			</div>