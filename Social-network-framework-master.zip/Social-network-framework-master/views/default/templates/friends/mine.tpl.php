			<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
					<h1>Your connections</h1>
					<p>You are...</p>
					<ul>
					<!-- START connections -->
					<li>{plural_name} with {users_name}</p>
					<!-- END connections -->
					</ul>
				</div>
			
			</div>