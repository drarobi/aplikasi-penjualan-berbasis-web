<?php

$configs = array();
$configs['db_host_sn'] = 'localhost';
$configs['db_user_sn'] = 'root';
$configs['db_pass_sn'] = 'phplover';
$configs['db_name_sn'] = 'dummy';


?>
